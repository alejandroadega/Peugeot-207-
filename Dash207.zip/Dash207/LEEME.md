# Dash 207 (Jetpack Compose) para Junsun V1 Pro

## Compilar el APK
1. Instala Android Studio (Koala o más nuevo) y abre la carpeta Dash207.
2. Espera al Gradle Sync (necesita internet la primera vez).
3. Menú Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. El APK queda en app/build/outputs/apk/debug/app-debug.apk

## Instalar por USB
- Opción A: copia el APK a un pendrive, ábrelo con el gestor de archivos de la radio e instala.
- Opción B (adb): `adb install -r app-debug.apk` (activa depuración USB en la radio).

## Uso
- Empareja el ELM327 en los ajustes Bluetooth de la radio (PIN 1234 o 0000).
- Pulsación larga en pantalla: modo demo. Doble toque: ver log de broadcasts.

## Sacar puertas y luces del CANBUS de la radio
Las claves en data/RadioCanSource.kt (CanConfig) son suposiciones. Para encontrar las reales:
1. Conecta la radio por adb y abre puertas con la app abierta.
2. `adb logcat -v time | grep -i -E "canbus|door|can_"`
3. Copia la acción del broadcast y los nombres de los extras a CanConfig.
Si tu firmware no emite broadcasts (usa un servicio propio), pásame el log y adapto la fuente.

## Notas
- Consumo: calculado con MAF (gasolina). Es estimado, no medido por inyección.
- Rojo de zona roja a 6500 rpm y fondo de escala 8000: ajusta en RevGauge.
