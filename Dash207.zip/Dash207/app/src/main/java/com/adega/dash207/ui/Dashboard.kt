package com.adega.dash207.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adega.dash207.data.*
import kotlin.math.cos
import kotlin.math.sin

val Rojo = Color(0xFFE10600); val RojoOscuro = Color(0xFF6E0000); val Fondo = Color(0xFF0A0A0B)
val Panel = Color(0xFF17171B); val Ink = Color(0xFFF2F2F2); val Dim = Color(0xFF6B6B73)
val Ambar = Color(0xFFFFB000); val Azul = Color(0xFF2E9BFF); val Verde = Color(0xFF22C55E)

@Composable
fun Dashboard(onToggleDemo: () -> Unit) {
    val s by DataHub.state.collectAsState()
    val log by DataHub.log.collectAsState()
    var showLog by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B1B20), Fondo)))
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onToggleDemo() }, onDoubleTap = { showLog = !showLog }) }
    ) {
        Row(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 30.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
                CarTopView(s.doors, Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row { Ind("◀", s.lights.left, Verde); Ind("LUCES", s.lights.low, Verde); Ind("▶", s.lights.right, Verde) }
                Row { Ind("LARGAS", s.lights.high, Azul); Ind("NIEBLA", s.lights.fog, Ambar) }
            }
            RevGauge(s, Modifier.weight(1.7f).fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
                InfoTile("TEMP. AGUA", s.coolantC?.toString() ?: "--", "°C", warn = (s.coolantC ?: 0) > 105)
                InfoTile("CONSUMO", s.lPer100?.let { "%.1f".format(it.coerceAtMost(99f)) } ?: "--", "L/100")
                InfoTile("DEPÓSITO", s.fuelLevelPct?.toString() ?: "--", "%", warn = (s.fuelLevelPct ?: 100) < 15)
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            listOf(s.obdStatus, s.canStatus, s.gpsStatus).forEach { t ->
                Text(t, color = if (t.endsWith("OK") || t == "DEMO") Verde else Dim, fontSize = 12.sp)
            }
        }
        if (showLog) Column(Modifier.fillMaxSize().background(Color(0xE6000000)).padding(12.dp)) {
            Text("LOG (doble toque para cerrar · pulsación larga = demo)", color = Ambar, fontSize = 12.sp)
            log.takeLast(25).forEach { Text(it, color = Ink, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 1) }
        }
    }
}

@Composable
fun RevGauge(s: CarState, modifier: Modifier = Modifier) {
    val maxRpm = 8000f; val redline = 6500f
    val rpm by animateFloatAsState(s.rpm.toFloat(), tween(120), label = "rpm")
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true; color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxHeight().aspectRatio(1f)) {
            val m = size.minDimension; val stroke = m * 0.07f; val d = m - stroke
            val tl = Offset(stroke / 2, stroke / 2); val arc = Size(d, d)
            drawArc(Panel, 135f, 270f, false, tl, arc, style = Stroke(stroke))
            drawArc(RojoOscuro, 135f + 270f * redline / maxRpm, 270f * (maxRpm - redline) / maxRpm, false, tl, arc, style = Stroke(stroke))
            drawArc(if (rpm >= redline) Ambar else Rojo, 135f, 270f * (rpm / maxRpm).coerceIn(0f, 1f), false, tl, arc, style = Stroke(stroke))
            val c = center; val r = d / 2; paint.textSize = m * 0.06f
            for (i in 0..8) {
                val a = Math.toRadians(135.0 + 270.0 * i / 8); val cx = cos(a).toFloat(); val sy = sin(a).toFloat()
                drawLine(Ink, c + Offset(cx, sy) * (r - stroke), c + Offset(cx, sy) * (r - stroke * 1.7f), strokeWidth = 4f)
                drawIntoCanvas { it.nativeCanvas.drawText("$i", c.x + cx * (r - stroke * 2.8f), c.y + sy * (r - stroke * 2.8f) + paint.textSize / 3, paint) }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${s.speedKmh}", color = Ink, fontSize = 104.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
            Text("KM/H", color = Rojo, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("${s.rpm} rpm", color = Dim, fontSize = 16.sp)
        }
    }
}

@Composable
fun CarTopView(d: Doors, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height; val bw = minOf(w * 0.5f, h * 0.45f); val x0 = (w - bw) / 2
        drawRoundRect(Panel, Offset(x0, h * 0.04f), Size(bw, h * 0.88f), CornerRadius(bw * 0.35f))
        drawRoundRect(Dim, Offset(x0, h * 0.04f), Size(bw, h * 0.88f), CornerRadius(bw * 0.35f), style = Stroke(3f))
        drawRoundRect(Color(0xFF24262C), Offset(x0 + bw * 0.1f, h * 0.26f), Size(bw * 0.8f, h * 0.12f), CornerRadius(8f))
        val dw = bw * 0.16f; val dh = h * 0.18f
        fun door(left: Boolean, y: Float, open: Boolean) {
            val x = if (left) (if (open) x0 - dw * 1.6f else x0 - dw * 0.5f) else (if (open) x0 + bw + dw * 0.6f else x0 + bw - dw * 0.5f)
            drawRoundRect(if (open) Rojo else Color(0xFF30303A), Offset(x, y), Size(dw, dh), CornerRadius(6f))
        }
        door(true, h * 0.40f, d.fl); door(false, h * 0.40f, d.fr)
        door(true, h * 0.60f, d.rl); door(false, h * 0.60f, d.rr)
        drawRoundRect(if (d.trunk) Rojo else Color(0xFF30303A), Offset(x0 + bw * 0.15f, if (d.trunk) h * 0.94f else h * 0.88f), Size(bw * 0.7f, h * 0.05f), CornerRadius(6f))
    }
}

@Composable
fun InfoTile(title: String, value: String, unit: String, warn: Boolean = false) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel)) {
        Box(Modifier.width(5.dp).height(78.dp).background(if (warn) Ambar else Rojo))
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Dim, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = if (warn) Ambar else Ink, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text(" $unit", color = Dim, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
        }
    }
}

@Composable
fun Ind(label: String, on: Boolean, color: Color) {
    Text(label, color = if (on) color else Color(0xFF2C2C32), fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
}
