package com.adega.dash207.data

import kotlinx.coroutines.flow.*

data class Doors(val fl: Boolean = false, val fr: Boolean = false, val rl: Boolean = false, val rr: Boolean = false, val trunk: Boolean = false)
data class Lights(val low: Boolean = false, val high: Boolean = false, val fog: Boolean = false, val left: Boolean = false, val right: Boolean = false)

data class CarState(
    val speedKmh: Int = 0,
    val rpm: Int = 0,
    val coolantC: Int? = null,
    val fuelLevelPct: Int? = null,
    val fuelLph: Float? = null,
    val lPer100: Float? = null,
    val doors: Doors = Doors(),
    val lights: Lights = Lights(),
    val speedSource: String = "",
    val obdStatus: String = "OBD: iniciando",
    val canStatus: String = "CAN: sin datos",
    val gpsStatus: String = "GPS: sin señal",
)

object DataHub {
    private val _state = MutableStateFlow(CarState())
    val state: StateFlow<CarState> = _state.asStateFlow()
    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()

    fun update(f: (CarState) -> CarState) { _state.update(f) }
    fun log(s: String) { _log.update { (it + s).takeLast(40) } }

    // Prioridad de velocidad: OBD > CAN de la radio > GPS (si el dato tiene menos de 3 s)
    private val speeds = HashMap<String, Pair<Int, Long>>()
    private val priority = listOf("OBD", "CAN", "GPS")

    @Synchronized
    fun pushSpeed(src: String, kmh: Int) {
        val now = System.currentTimeMillis()
        speeds[src] = kmh to now
        val best = priority.firstOrNull { p -> speeds[p]?.let { now - it.second < 3000 } == true } ?: return
        update { it.copy(speedKmh = speeds[best]!!.first, speedSource = best) }
    }
}
