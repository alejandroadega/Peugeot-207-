package com.adega.dash207.data

import android.content.*

/**
 * Lee los broadcasts que la radio emite con los datos del decodificador CANBUS.
 * Las acciones y claves de abajo son SUPOSICIONES: ajústalas tras ver el log real
 * (doble toque en pantalla = ver log) o con adb logcat. Ver LEEME.md.
 */
object CanConfig {
    val actions = listOf("com.canbus.data", "com.syu.canbus.update", "android.intent.action.CANBUS", "com.hzbhd.canbus.data")
    val speedKeys = listOf("speed", "car_speed", "vehicle_speed")
    val doors = mapOf(
        "fl" to listOf("door_fl", "door_lf", "lf_door", "front_left_door"),
        "fr" to listOf("door_fr", "door_rf", "rf_door", "front_right_door"),
        "rl" to listOf("door_rl", "door_lr", "lr_door", "rear_left_door"),
        "rr" to listOf("door_rr", "rr_door", "rear_right_door"),
        "trunk" to listOf("trunk", "door_trunk", "tailgate", "back_door"),
    )
    val lights = mapOf(
        "low" to listOf("low_beam", "light_low", "headlight"),
        "high" to listOf("high_beam", "light_high"),
        "fog" to listOf("fog", "fog_light", "light_fog"),
        "left" to listOf("turn_left", "left_turn", "light_left"),
        "right" to listOf("turn_right", "right_turn", "light_right"),
    )
}

class RadioCanSource(private val ctx: Context) {
    private fun toInt(v: Any?): Int? = when (v) {
        is Int -> v; is Long -> v.toInt(); is Float -> v.toInt(); is Double -> v.toInt()
        is String -> v.toFloatOrNull()?.toInt(); else -> null
    }
    private fun toBool(v: Any?): Boolean? = when (v) {
        is Boolean -> v; is Int -> v != 0
        is String -> v == "1" || v.equals("true", true) || v.equals("on", true); else -> null
    }

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context?, i: Intent?) {
            val ex = i?.extras ?: return
            DataHub.log("${i.action}: " + ex.keySet().joinToString { k -> "$k=${ex.get(k)}" })
            var d = DataHub.state.value.doors; var l = DataHub.state.value.lights
            for (k in ex.keySet()) {
                val key = k.lowercase(); val v = ex.get(k)
                if (key in CanConfig.speedKeys) toInt(v)?.let { DataHub.pushSpeed("CAN", it) }
                CanConfig.doors.forEach { (slot, names) -> if (key in names) toBool(v)?.let { b ->
                    d = when (slot) { "fl" -> d.copy(fl = b); "fr" -> d.copy(fr = b); "rl" -> d.copy(rl = b); "rr" -> d.copy(rr = b); else -> d.copy(trunk = b) } } }
                CanConfig.lights.forEach { (slot, names) -> if (key in names) toBool(v)?.let { b ->
                    l = when (slot) { "low" -> l.copy(low = b); "high" -> l.copy(high = b); "fog" -> l.copy(fog = b); "left" -> l.copy(left = b); else -> l.copy(right = b) } } }
            }
            DataHub.update { it.copy(doors = d, lights = l, canStatus = "CAN OK") }
        }
    }

    fun start() {
        val f = IntentFilter().also { fl -> CanConfig.actions.forEach { fl.addAction(it) } }
        ctx.registerReceiver(receiver, f)
    }
    fun stop() { try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {} }
}
