package com.adega.dash207

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.adega.dash207.data.*
import com.adega.dash207.ui.Dashboard
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var obd: ObdSource? = null
    private var can: RadioCanSource? = null
    private var gps: GpsSource? = null
    private var demo: DemoSource? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        setContent { Dashboard(onToggleDemo = { toggleDemo() }) }
        startReal()
    }

    private fun startReal() {
        obd = ObdSource(scope).also { it.start() }
        can = RadioCanSource(this).also { it.start() }
        gps = GpsSource(this).also { it.start() }
    }
    private fun stopReal() { obd?.stop(); can?.stop(); gps?.stop(); obd = null; can = null; gps = null }

    private fun toggleDemo() {
        if (demo == null) { stopReal(); demo = DemoSource(scope).also { it.start() } }
        else { demo?.stop(); demo = null; startReal() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        gps?.stop(); gps = GpsSource(this).also { it.start() }
    }

    override fun onDestroy() { stopReal(); demo?.stop(); scope.cancel(); super.onDestroy() }
}
