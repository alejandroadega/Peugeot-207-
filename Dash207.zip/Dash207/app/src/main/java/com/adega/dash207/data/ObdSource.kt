package com.adega.dash207.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import kotlinx.coroutines.*
import java.util.UUID

/** ELM327 Bluetooth (empareja antes el adaptador en los ajustes Bluetooth de la radio). */
@SuppressLint("MissingPermission")
class ObdSource(private val scope: CoroutineScope) {
    private var job: Job? = null

    fun start() {
        job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try { runSession() } catch (e: Exception) {
                    DataHub.update { it.copy(obdStatus = "OBD: reintentando") }
                    DataHub.log("OBD error: ${e.message}")
                }
                delay(4000)
            }
        }
    }
    fun stop() { job?.cancel() }

    private fun CoroutineScope.runSession() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val names = listOf("OBD", "ELM", "VLINK", "V-LINK", "VGATE", "VEEPEAK")
        val dev = adapter.bondedDevices.firstOrNull { d -> names.any { (d.name ?: "").uppercase().contains(it) } }
        if (dev == null) { DataHub.update { it.copy(obdStatus = "OBD: empareja el ELM327") }; return }
        DataHub.update { it.copy(obdStatus = "OBD: conectando") }
        val sock = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        adapter.cancelDiscovery()
        sock.connect()
        sock.use { s ->
            val inp = s.inputStream; val out = s.outputStream
            fun cmd(c: String, timeout: Long = 2000): String {
                out.write((c + "\r").toByteArray()); out.flush()
                val sb = StringBuilder(); val t0 = System.currentTimeMillis()
                while (System.currentTimeMillis() - t0 < timeout) {
                    if (inp.available() > 0) { val ch = inp.read().toChar(); if (ch == '>') break; sb.append(ch) } else Thread.sleep(10)
                }
                return sb.toString().replace("\r", "").replace("\n", "").replace(" ", "")
            }
            fun pid(p: String): IntArray? {
                val r = cmd(p); val key = "41" + p.substring(2)
                val i = r.indexOf(key); if (i < 0) return null
                return r.substring(i + key.length).chunked(2).mapNotNull { it.toIntOrNull(16) }.toIntArray()
            }
            listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0").forEach { cmd(it, 3000) }
            cmd("0100", 8000)
            DataHub.update { it.copy(obdStatus = "OBD OK") }
            val dead = mutableSetOf<String>()
            var n = 0; var fails = 0
            while (isActive) {
                val sp = pid("010D"); val rp = pid("010C")
                if (sp == null && rp == null) { if (++fails > 5) throw Exception("sin respuesta") } else fails = 0
                sp?.let { DataHub.pushSpeed("OBD", it[0]) }
                rp?.let { if (it.size >= 2) DataHub.update { s -> s.copy(rpm = (it[0] * 256 + it[1]) / 4) } }
                if (n % 10 == 0 && "0105" !in dead) pid("0105")?.let { DataHub.update { s -> s.copy(coolantC = it[0] - 40) } } ?: dead.add("0105")
                if (n % 20 == 0 && "012F" !in dead) pid("012F")?.let { DataHub.update { s -> s.copy(fuelLevelPct = it[0] * 100 / 255) } } ?: dead.add("012F")
                if (n % 3 == 0 && "0110" !in dead) {
                    val m = pid("0110")
                    if (m != null && m.size >= 2) {
                        val maf = (m[0] * 256 + m[1]) / 100f            // g/s
                        val lph = maf / 14.7f * 3600f / 745f            // gasolina (THP). Para diésel cambia 14.7 y 745
                        DataHub.update { s -> s.copy(fuelLph = lph, lPer100 = if (s.speedKmh > 5) lph / s.speedKmh * 100f else null) }
                    } else dead.add("0110")
                }
                n++
            }
        }
    }
}
