package com.adega.dash207.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlinx.coroutines.*
import kotlin.math.sin

class GpsSource(private val ctx: Context) {
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            DataHub.pushSpeed("GPS", (l.speed * 3.6f).toInt())
            DataHub.update { it.copy(gpsStatus = "GPS OK") }
        }
        override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }
    fun start() {
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Exception) {}
    }
    fun stop() { try { lm.removeUpdates(listener) } catch (_: Exception) {} }
}

/** Datos simulados para probar el diseño sin coche. */
class DemoSource(private val scope: CoroutineScope) {
    private var job: Job? = null
    fun start() {
        job = scope.launch {
            var t = 0.0
            while (isActive) {
                t += 0.05
                val k = (t / 3).toInt() % 6
                DataHub.pushSpeed("OBD", (70 + 60 * sin(t * 0.3)).toInt())
                DataHub.update {
                    it.copy(
                        rpm = (2500 + 2800 * (0.5 + 0.5 * sin(t * 0.9))).toInt(), coolantC = 90, fuelLevelPct = 62,
                        lPer100 = (7f + 2f * sin(t).toFloat()), fuelLph = 6f,
                        doors = Doors(fl = k == 1, fr = k == 2, rl = k == 3, rr = k == 4, trunk = k == 5),
                        lights = Lights(low = true, fog = k == 2, left = (t * 2).toInt() % 2 == 0),
                        obdStatus = "DEMO", canStatus = "DEMO", gpsStatus = "DEMO",
                    )
                }
                delay(50)
            }
        }
    }
    fun stop() { job?.cancel() }
}
